#!/usr/bin/env bash
set -euo pipefail
ROOT=${FM_PROOF_REPO:?}
WORLD="$SRC/readiness-live"
mkdir -p "$WORLD/bin"
"$ROOT/bin/fm-lab-home.sh" create "$WORLD/home" >/dev/null
export FM_HOME="$WORLD/home"
git init -q -b fm/task "$WORLD/repo"
git -C "$WORLD/repo" commit -q --allow-empty -m 'published candidate'
head=$(git -C "$WORLD/repo" rev-parse HEAD)
git -C "$WORLD/repo" update-ref refs/remotes/origin/fm/task "$head"
cat > "$WORLD/bin/gh" <<'SH'
#!/usr/bin/env bash
printf 'gh %s\n' "$*" >> "$READY_LOG"
[ "${READY_PROOF:-main}" != unreadable ] || exit 1
case " $* " in
  *' --json baseRefName '*) printf '%s\n' "${READY_PROOF:-main}" ;;
  *) exit 1 ;;
esac
SH
chmod +x "$WORLD/bin/gh"
export PATH="$WORLD/bin:$PATH" READY_LOG="$WORLD/forge.log"
: > "$READY_LOG"
for mode in direct-PR no-mistakes; do
  for proof in main wrong unreadable missing; do
    printf 'worktree=%s\nproject=%s\nkind=ship\nharness=codex\nmode=%s\npr=https://github.com/o/r/pull/12\npr_head=%s\n' "$WORLD/repo" "$WORLD/repo" "$mode" "$head" > "$FM_HOME/state/task.meta"
    [ "$proof" = missing ] || printf 'expected_base=main\n' >> "$FM_HOME/state/task.meta"
    notes=('PR https://github.com/o/r/pull/12 checks green' 'checks green: https://github.com/o/r/pull/12' 'PR #12 checks green' 'checks green: PR#12' 'https://github.com/o/r/pull/12 checks green' 'https://gitlab.com/o/r/-/merge_requests/12 checks green' 'https://git.example.org/team/repo/pulls/12 checks green' '/pull/12 checks green' 'checks green after review (https://github.com/o/r/pull/12)' 'PR http://github.com/o/r/pull/12 checks green')
    if [ "$mode" = direct-PR ]; then
      notes+=('PR https://github.com/o/r/pull/12' 'PR #12' 'opened https://github.com/o/r/pull/12' 'https://github.com/o/r/pull/12' '/pull/12' 'implementation complete')
    fi
    for note in "${notes[@]}"; do
      printf 'done: %s\n' "$note" > "$FM_HOME/state/task.status"
      out=$(READY_PROOF="$proof" FM_CREW_STATE_NO_FORGE=1 "$ROOT/bin/fm-crew-state.sh" task)
      printf 'READINESS mode=%s proof=%s note=%s\n%s\n' "$mode" "$proof" "$note" "$out"
      if [ "$proof" = main ] && { [ "$note" = 'PR https://github.com/o/r/pull/12 checks green' ] || [ "$note" = 'PR https://github.com/o/r/pull/12' ]; }; then
        case "$out" in 'state: done '*) ;; *) exit 1 ;; esac
      else
        case "$out" in 'state: blocked '*) ;; *) exit 1 ;; esac
        case "$out" in *'expected PR base'*|*'PR destination could not be resolved'*) ;; *) exit 1 ;; esac
      fi
    done
  done
done
cat "$READY_LOG"
printf 'READINESS_PUBLIC_CLI_EXIT=0\n'
